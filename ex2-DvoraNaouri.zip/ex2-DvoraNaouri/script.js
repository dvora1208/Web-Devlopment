//functions listener to click and keyup

document.addEventListener("DOMContentLoaded", function () {

    document.getElementById("myB").addEventListener("click", clickonB)
    document.getElementById('numofchild').addEventListener('keyup', clickonkeyb)
    document.getElementById("myB2").addEventListener("click", clickonB2)
})

//what will appen whene you click on the botton "send"
function clickonB() {

    console.log("hey")
    //all time whene you enter details the alert need to be block
    // document.getElementById("al-danger").classList.remove("d-block");//Gavi -// like that????

    //get the input
    let input1 = document.getElementById("input-text").value.trim();
    let input2 = document.getElementById("input-text2").value.trim();
    let input3 = document.getElementById("input-text3").value.trim();
    let input4 = document.getElementById("input-text4").value.trim();
    let input5 = document.getElementById("numofchild").value.trim();

    //Setting Variables
    var alert = document.getElementById("al-danger");
    var today = new Date();
    //insert the input after validation in a vector
    var details = [input1, input2, input3, input4];

    // console.log(details)
    var mychildreninput = document.querySelectorAll(".inputforchild")

    console.log(mychildreninput)
    //put the children name in a array
    var mychildreninputarray = Array.from(mychildreninput)
    var mychildrenname = mychildreninputarray.map((childname) => {
        return childname.value.trim()
    })

    console.log(mychildrenname)

    //conter the eror
    var eror = 0

    document.getElementById("al-danger").classList.add("d-none")

//chack number of child
    if (input5 >10 ) {
        eror++
        alert.style.display = "block";
        document.getElementById("uncorrectnumber").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }

    //cheack if birth year is ok
    if (input3 < 1900) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_byear").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }
    if (input3 > today.getFullYear()) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_byear").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");

    }
    //check if immigrition year is after birth year
    if (input4 < input3) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_imyear").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");

    }
    if (input4 > today.getFullYear()) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_imyear").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");

    }
    //cheak if the inputs isnt empty
    if (!input1) {
        eror++
        console.log("ggg")
        console.log(alert)
        alert.style.display = "block";
        document.getElementById("alert_first").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }
    if (!input2) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_last").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }
    if (!input3) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_byearmissing").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }
    if (!input4) {
        eror++
        alert.style.display = "block";
        document.getElementById("alert_immiss").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }
     mychildrenname.map((childname)=>{
         if(childname===''){
             eror++

             alert.style.display = "block";
             document.getElementById("alert_childmiss").classList.remove("d-none");
             document.getElementById("al-danger").classList.remove("d-none");

         }
     })
         //chack if have 2 child with the same name
    mychildrenname.map((childname1, index1)=>{
        mychildrenname.map((childname2, index2)=>{
            if(index1!==index2)
            {
                if(childname1===childname2){
                    eror++
                    alert.style.display = "block";
                         document.getElementById("alert_child").classList.remove("d-none");
                         document.getElementById("al-danger").classList.remove("d-none");
                }
            }

        })
    })
    //if input is more than 10 child
    if (input5>10){
        eror++
        alert.style.display = "block";
        document.getElementById("uncorrectnumber").classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }

    ///the final print of the form if thare is no eror
    if(eror===0){
        document.getElementById("finallform").classList.remove("d-none");
        document.getElementById("Form").classList.add("d-none")
        document.getElementById("al-danger").classList.add("d-none")
        mychildrenname.sort()

        myfinallform= document.createElement("div")
        var h1 = document.createElement("h1")
        myfinallform.appendChild(h1)

        myfinallform.innerText+='first name:'+input1;
        document.getElementById("finallform").appendChild(myfinallform)

        var br= document.createElement("br")
        myfinallform.appendChild(br)

        myfinallform.innerText+='last name:'+input2;
        document.getElementById("finallform").appendChild(myfinallform)
        myfinallform.appendChild(br)

        myfinallform.innerText+='birth year:'+input3;
        document.getElementById("finallform").appendChild(myfinallform)
        myfinallform.appendChild(br)

        myfinallform.innerText+='immigrition year:'+input4;
        document.getElementById("finallform").appendChild(myfinallform)
        myfinallform.appendChild(br)

        mychildrenname.map((childname,i)=>{
            myfinallform.innerText+="child" + (i + 1) +": " + childname
            myfinallform.appendChild(br)
        })

        myfinallform.appendChild(br)
        document.getElementById("myB").classList.add("d-none");
        document.getElementById("myB2").classList.add("d-block");

    }


}
//refresh page
function clickonB2() {
    console.log("rrrrr")
    document.getElementById("finallform").classList.add("d-none");

    document.getElementById("Form").classList.remove("d-none");

    let input1 = document.getElementById("input-text");
    input1.value = ''

    let input2 = document.getElementById("input-text2");
    input2.value = ''
    let input3 = document.getElementById("input-text3");
    input3.value = ''
    let input4 = document.getElementById("input-text4");
    input4.value = ''
    let input5 = document.getElementById("numofchild");
    input5.value = ''

    //remove childbox
    var mychildreninput = document.querySelectorAll(".inputforchild")
    var mychildreninputarray = Array.from(mychildreninput)

    mychildreninputarray.map((child)=>{
        child.value=''
    })

    //remove and add the corect botton
    document.getElementById("myB").classList.remove("d-none");
    document.getElementById("myB2").classList.remove("d-block");
    clickonkeyb()

    myfinallform.innerText='';
}

//howmany child box are open
var howmany = 0

//click on nuber on child
function clickonkeyb() {

    let input = document.getElementById("numofchild").value.trim();
    console.log(input);

    //need more box
    if (!isNaN(input)) {

        if (input > howmany) {
            if (input>10)
             {input=10}
            //the place in the html wher we need new box
            var newbox = document.getElementById("newbox")
            while (howmany < input) {
                var child = document.createElement("div")
                var mylabel = document.createElement("label")
                //print child num x: and a box
                mylabel.textContent = "child name " + (howmany + 1) + ": "
                var inputnextchild = document.createElement("input")
                inputnextchild.setAttribute("type", "text")
                inputnextchild.setAttribute("class", "inputforchild")
                child.setAttribute("class", "mychildern")
                child.appendChild(mylabel)
                child.appendChild(inputnextchild)
                newbox.appendChild(child)
                howmany++
            }
        }
        //need less box
        if (input < howmany) {
            while (howmany > input) {

                var mychildern = document.querySelectorAll(".mychildern")
                console.log(mychildern)
                var child = mychildern[mychildern.length - 1]
                child.parentNode.removeChild(child)

                howmany--
            }

        }
    }
}









