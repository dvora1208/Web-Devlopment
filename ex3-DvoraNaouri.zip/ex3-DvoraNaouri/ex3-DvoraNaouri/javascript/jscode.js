(function () {
    document.addEventListener(
        "DOMContentLoaded",
        function () {
            document.querySelector("button").addEventListener("click", createItem);
            document.getElementById("myBDelet").addEventListener("click", deleteItem);
            document.getElementById("myBShow").addEventListener("click", showWeather);
            document.getElementById("image").classList.add("d-none");
        },
        false
    );

/////////////////////////////////////////////////////////////////////////////////////
//a map with all the locations that the user input
    var location = new Map();

/////////////////////////////////////////////////////////////////////////////////////
//remove the area that the user chose to remove when he click on the delet botton
// the getOption function singh the area that the user want to delet
    function deleteItem() {
        let my_input = getOption();
        my_input.parentElement.removeChild(my_input);
    }

/////////////////////////////////////////////////////////////////////////////////////
//this function show the weather of the area that the user want with the getOption()
// function the function get the relevant number and with the fetch () function she take the
// right data and the corect image for the user and than with another function she print on
// the dom the weather

    function showWeather() {

        let my_location = getOption();
        let lati = my_location.getAttribute("latitude");
        let long = my_location.getAttribute("longitude");

        let image = "http://www.7timer.info/bin/astro.php?lon=" + long + "&amp;lat=" + lati + "&amp;ac=0&amp;lang=en&amp;unit=metric&amp;output=internal&amp;tzshift=0"
        let place = document.getElementById("image")
        place.setAttribute("src", image)
        place.classList.remove("d-none")

        document.getElementById("myBShow").classList.add("d-none");
        fetch(
            "http://www.7timer.info/bin/api.pl?" +
            new URLSearchParams({
                lon: long,
                lat: lati,
                product: "civillight",
                output: "json",
            })
        ).then((resolt) => {
            resolt.json().then((data) => {
                document.getElementById("myW").innerHTML = " "
                getWeather(data)
            })
        })
            .catch((eror) => {
                window.alert("Error not expected, try again later " + eror)
            })
    }

///////////////////////////////////////////////////////////////////////////////////
//function that take from the data from the url the thing that interest the user and print tham
// on the dom

    function getWeather(data) {
        const dataseries = data.dataseries

        let weatehr = document.getElementById("myW")

        dataseries.map((ds) => {

            const W = ds.weather
            const TMin = ds.temp2m.min
            const TMax = ds.temp2m.max
            const wind = ds.wind10m_max
            const date = ds.date + ''
            const year = date.substring(0, 4)
            const month = date.substring(4, 6)
            const day = date.substring(6, 8)
            weatehr.innerHTML += year + "." + month + "." + day + ": <h6 class='d-inline'>Weather:</h6>"
                + W + "<h6 class='d-inline'> , Temp-min:</h6>" + TMin +
                "<h6 class='d-inline'> , Temp-max:</h6>" + TMax + "<h6 class='d-inline'> , Wind:</h6>" +
                wind + "<br>";
        })


        document.getElementById("myBShow").classList.remove("d-none");
    }

/////////////////////////////////////////////////////////////////////////////////////
//function that get the  mark option from the dropdown list

    function getOption() {
        selectElement = document.querySelector("#list1");
        output = selectElement.options[selectElement.selectedIndex];

        return output;
    }

/////////////////////////////////////////////////////////////////////////////////////
/// this function get the input from the user and cheak if he insert aa corect
// input if not she send a eror massage

    function cheaktheinput() {
        var eror = 0;
        var name_input = document.getElementById("user-input").value.trim();
        var latitude_input = document.getElementById("user-input2").value.trim();
        var longitude_input = document.getElementById("user-input3").value.trim();

        var alert = document.getElementById("al-danger");
        document.getElementById("al-danger").classList.add("d-none");
        document.getElementById("alert_Latitude3").classList.add("d-none");
        document.getElementById("alert_Longitude3").classList.add("d-none");
        document.getElementById("alert_Latitude").classList.add("d-none");
        document.getElementById("alert_Longitude").classList.add("d-none");
        document.getElementById("alert_Name").classList.add("d-none");
        document.getElementById("alert_Name2").classList.add("d-none");
        document.getElementById("alert_Latitude2").classList.add("d-none");
        document.getElementById("alert_Longitude2").classList.add("d-none");

        //CHEAK IF THE INPUT IS CORECT

        if (latitude_input > 90) {
            handleAlert("alert_Latitude3");
            eror++;
        }
        if (latitude_input < -90) {
            handleAlert("alert_Latitude3");
            eror++;
        }
        if (longitude_input < -180) {
            handleAlert("alert_Longitude3");
            eror++;
        }
        if (longitude_input > 180) {

            handleAlert("alert_Longitude3");
            eror++;
        }
        if (isNaN(latitude_input)) {
            handleAlert("alert_Latitude");
            eror++;
        }
        if (isNaN(longitude_input)) {
            handleAlert("alert_Longitude");
            eror++;
        }
        if (!isNaN(name_input)) {
            handleAlert("alert_Name");
            eror++;
        }
        if (!name_input) {
            handleAlert("alert_Name2");
            eror++;
        }
        if (!latitude_input) {
            handleAlert("alert_Latitude2");
            eror++;
        }
        if (!longitude_input) {
            handleAlert("alert_Longitude2");
            eror++;
        }
        return eror;
    }

/////////////////////////////////////////////////////////////////////////////////////////////////
//a function that will appan evry "if" that cheack the input in the cheaktheinput() function

    function handleAlert(alertid) {
        var alert = document.getElementById("al-danger");
        alert.style.display = "block";
        document.getElementById(alertid).classList.remove("d-none");
        document.getElementById("al-danger").classList.remove("d-none");
    }

/////////////////////////////////////////////////////////////////////////////////////
//if all the input is ok the eror will be 0 and that this function
// wiil creat the item in the dropdown list , befor this the function cheak if the
// item dosnt exist yet in the dropdown list

    function createItem() {
        var name_input = document.getElementById("user-input").value.trim();
        var latitude_input = document.getElementById("user-input2").value.trim();
        var longitude_input = document.getElementById("user-input3").value.trim();

        //  var alert = document.getElementById("al-danger");

        var eror = cheaktheinput();

        if (eror === 0) {
            document.getElementById("al-danger").classList.add("d-none");

            var newlocation = {
                name: name_input,
                Latitude: latitude_input,
                Longitude: longitude_input
            }

            location[newlocation.name] = newlocation;
            hedledouble(newlocation.name)
            addLocationToTheList(name_input, longitude_input, latitude_input);

        }
////////////////////////////////////////////////////
//this function delet the old item in the list if the user want to add the
// same name input agine , the function chack in the name of the new locatin
// exist in the list and then the name with the new values insert in the list

        function hedledouble(mylocation) {
            let select = document.getElementById("list1")
            for (let i = 0; i < select.length; i++) {
                if (select.options[i].innerText.startsWith("Name:" + mylocation)) {
                    select.selectedIndex = i;
                    deleteItem();
                    break
                }
            }
        }

////////////////////////////////////////////////////////////////////////////////////////
// this function add the item to the dropdown list after all the cheak on the input

        function addLocationToTheList(name_input, longitude_input, latitude_input) {
            var newitem = document.createElement("option");

            var list = document.getElementById("list1");
            var newtext = document.createTextNode;

            newitem.text =
                "Name:" +
                name_input +
                ", Latitude:" +
                latitude_input +
                ", Longitude:" +
                longitude_input;
            newitem.value = name_input;
            newitem.setAttribute("latitude", latitude_input);
            newitem.setAttribute("longitude", longitude_input);
            list.appendChild(newitem);
        }

    }

})();