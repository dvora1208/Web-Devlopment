document.addEventListener("DOMContentLoaded",function(){
    document.getElementById("list").style.display = "none";

    document.getElementById("myB").addEventListener("click", function(){
        var list = document.getElementById("list");
        if (list.style.display === "block"){
            list.style.display = "none";
            document.getElementById("myB").innerText = "פתח";

        } else {
            list.style.display = "block";
            document.getElementById("myB").innerText = "סגור";
        }

    })
})